create table if not exists domainEntity(
    id int auto_increment primary key,
    name varchar(32)
);
